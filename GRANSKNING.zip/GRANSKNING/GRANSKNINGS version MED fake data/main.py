"""
Författare: Fredrik Stoltz
Datum: 17/11-2019
"""

"""
Importerar huvudmenyn och startar programmet genom att ropa på huvudmenyn.
"""

from funktioner import huvudMeny


huvudMeny()


